import { useParams, Link } from "react-router";
import { useState, useMemo } from "react";
import { ArrowRight, Filter, SlidersHorizontal } from "lucide-react";
import { liftModels, liftCategories, liftSubcategories } from "../data/lifts";
import { motion } from "motion/react";

export function SubCategory() {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [selectedCapacity, setSelectedCapacity] = useState<string>("all");
  const [selectedBuildingType, setSelectedBuildingType] = useState<string>("all");
  const [selectedUsage, setSelectedUsage] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(true);

  const category = liftCategories.find((c) => c.id === categoryId);
  const subcategories = liftSubcategories.filter((s) => s.categoryId === categoryId);
  const models = liftModels.filter((m) => 
    subcategories.some((sub) => sub.id === m.subcategoryId)
  );

  // Extract unique filter options
  const capacityRanges = [
    { label: "Up to 500 kg", min: 0, max: 500 },
    { label: "500 - 1000 kg", min: 500, max: 1000 },
    { label: "1000 - 2000 kg", min: 1000, max: 2000 },
    { label: "Over 2000 kg", min: 2000, max: Infinity },
  ];

  const buildingTypes = Array.from(
    new Set(models.flatMap((m) => m.buildingType))
  ).sort();

  const usageTypes = Array.from(
    new Set(models.flatMap((m) => m.usage))
  ).sort();

  // Filter models
  const filteredModels = useMemo(() => {
    return models.filter((model) => {
      // Capacity filter
      if (selectedCapacity !== "all") {
        const range = capacityRanges[parseInt(selectedCapacity)];
        if (model.capacity < range.min || model.capacity > range.max) {
          return false;
        }
      }

      // Building type filter
      if (selectedBuildingType !== "all") {
        if (!model.buildingType.includes(selectedBuildingType)) {
          return false;
        }
      }

      // Usage filter
      if (selectedUsage !== "all") {
        if (!model.usage.includes(selectedUsage)) {
          return false;
        }
      }

      return true;
    });
  }, [models, selectedCapacity, selectedBuildingType, selectedUsage]);

  if (!category) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl mb-4">Category not found</h1>
        <Link to="/categories" className="text-primary">
          Back to categories
        </Link>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Header */}
      <section
        className="relative py-16 md:py-24 border-b border-border overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,0.98)), url(${category.image})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Link
              to="/categories"
              className="text-sm text-muted-foreground hover:text-foreground mb-4 inline-flex items-center gap-2"
            >
              ← Back to Categories
            </Link>
            <h1 className="text-4xl md:text-6xl mb-4 tracking-tight">
              {category.name}
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mb-8">
              {category.description}
            </p>

            {/* Subcategories Navigation */}
            <div className="flex flex-wrap gap-3">
              {subcategories.map((subcat) => (
                <div
                  key={subcat.id}
                  className="px-4 py-2 bg-background border border-border rounded-lg"
                >
                  <span className="font-mono">{subcat.code}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Filters and Products */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar */}
            <div className="lg:w-64 flex-shrink-0">
              <div className="sticky top-24">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="flex items-center gap-2">
                    <Filter className="w-5 h-5" />
                    <span>Filters</span>
                  </h2>
                  <button
                    onClick={() => setShowFilters(!showFilters)}
                    className="lg:hidden p-2"
                  >
                    <SlidersHorizontal className="w-5 h-5" />
                  </button>
                </div>

                <div className={`space-y-6 ${showFilters ? "block" : "hidden lg:block"}`}>
                  {/* Capacity Filter */}
                  <div className="pb-6 border-b border-border">
                    <h3 className="text-sm uppercase tracking-wide mb-4 text-muted-foreground">
                      Load Capacity
                    </h3>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="capacity"
                          value="all"
                          checked={selectedCapacity === "all"}
                          onChange={(e) => setSelectedCapacity(e.target.value)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm">All Capacities</span>
                      </label>
                      {capacityRanges.map((range, idx) => (
                        <label key={idx} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="radio"
                            name="capacity"
                            value={idx.toString()}
                            checked={selectedCapacity === idx.toString()}
                            onChange={(e) => setSelectedCapacity(e.target.value)}
                            className="w-4 h-4"
                          />
                          <span className="text-sm">{range.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Building Type Filter */}
                  <div className="pb-6 border-b border-border">
                    <h3 className="text-sm uppercase tracking-wide mb-4 text-muted-foreground">
                      Building Type
                    </h3>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="buildingType"
                          value="all"
                          checked={selectedBuildingType === "all"}
                          onChange={(e) => setSelectedBuildingType(e.target.value)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm">All Types</span>
                      </label>
                      {buildingTypes.map((type) => (
                        <label key={type} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="radio"
                            name="buildingType"
                            value={type}
                            checked={selectedBuildingType === type}
                            onChange={(e) => setSelectedBuildingType(e.target.value)}
                            className="w-4 h-4"
                          />
                          <span className="text-sm">{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Usage Filter */}
                  <div className="pb-6">
                    <h3 className="text-sm uppercase tracking-wide mb-4 text-muted-foreground">
                      Usage Type
                    </h3>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="usage"
                          value="all"
                          checked={selectedUsage === "all"}
                          onChange={(e) => setSelectedUsage(e.target.value)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm">All Usage</span>
                      </label>
                      {usageTypes.map((type) => (
                        <label key={type} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="radio"
                            name="usage"
                            value={type}
                            checked={selectedUsage === type}
                            onChange={(e) => setSelectedUsage(e.target.value)}
                            className="w-4 h-4"
                          />
                          <span className="text-sm">{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Reset Filters */}
                  <button
                    onClick={() => {
                      setSelectedCapacity("all");
                      setSelectedBuildingType("all");
                      setSelectedUsage("all");
                    }}
                    className="w-full px-4 py-2 text-sm border border-border rounded-lg hover:bg-secondary transition-colors"
                  >
                    Reset Filters
                  </button>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className="flex-1">
              <div className="mb-6">
                <p className="text-muted-foreground">
                  Showing {filteredModels.length} of {models.length} products
                </p>
              </div>

              {filteredModels.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-muted-foreground mb-4">
                    No products match your filters
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCapacity("all");
                      setSelectedBuildingType("all");
                      setSelectedUsage("all");
                    }}
                    className="text-primary"
                  >
                    Clear all filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredModels.map((model, index) => {
                    const modelSubcategory = liftSubcategories.find(
                      (s) => s.id === model.subcategoryId
                    );
                    
                    return (
                      <motion.div
                        key={model.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Link
                          to={`/product/${model.id}`}
                          className="group block bg-card border border-border rounded-lg overflow-hidden hover:shadow-xl transition-all"
                        >
                          <div className="relative h-48 overflow-hidden bg-muted">
                            <img
                              src={model.image}
                              alt={model.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute top-3 left-3 bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-mono">
                              {model.code}
                            </div>
                            {modelSubcategory && (
                              <div className="absolute top-3 right-3 bg-background/90 backdrop-blur px-2 py-1 rounded text-xs">
                                {modelSubcategory.name}
                              </div>
                            )}
                          </div>
                          <div className="p-5">
                            <h3 className="text-lg mb-2 group-hover:text-primary transition-colors">
                              {model.name}
                            </h3>
                            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                              {model.description}
                            </p>

                            {/* Specs */}
                            <div className="grid grid-cols-2 gap-2 mb-4 text-xs">
                              <div className="p-2 bg-secondary/50 rounded">
                                <div className="text-muted-foreground">Capacity</div>
                                <div className="font-mono">{model.capacity} kg</div>
                              </div>
                              <div className="p-2 bg-secondary/50 rounded">
                                <div className="text-muted-foreground">Speed</div>
                                <div className="font-mono">{model.speed}</div>
                              </div>
                            </div>

                            {/* Price & CTA */}
                            <div className="flex items-center justify-between pt-4 border-t border-border">
                              <div>
                                <div className="text-xs text-muted-foreground">Starting at</div>
                                <div className="text-lg font-mono">${model.price.toLocaleString()}</div>
                              </div>
                              <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
                            </div>
                          </div>
                        </Link>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
