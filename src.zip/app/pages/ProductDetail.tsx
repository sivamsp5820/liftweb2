import { useParams, Link, useNavigate } from "react-router";
import { useState } from "react";
import {
  ArrowLeft,
  Download,
  CheckCircle2,
  Shield,
  Zap,
  Package,
  ChevronRight,
} from "lucide-react";
import { liftModels, addons, liftCategories, liftSubcategories } from "../data/lifts";
import { motion } from "motion/react";

export function ProductDetail() {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedAddons, setSelectedAddons] = useState<Set<string>>(new Set());

  const model = liftModels.find((m) => m.id === productId);
  const subcategory = model ? liftSubcategories.find((s) => s.id === model.subcategoryId) : null;
  const category = subcategory ? liftCategories.find((c) => c.id === subcategory.categoryId) : null;

  if (!model || !subcategory || !category) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl mb-4">Product not found</h1>
        <Link to="/categories" className="text-primary">
          Back to categories
        </Link>
      </div>
    );
  }

  const toggleAddon = (addonId: string) => {
    const newSet = new Set(selectedAddons);
    if (newSet.has(addonId)) {
      newSet.delete(addonId);
    } else {
      newSet.add(addonId);
    }
    setSelectedAddons(newSet);
  };

  const calculateTotal = () => {
    const addonsTotal = Array.from(selectedAddons).reduce((sum, addonId) => {
      const addon = addons.find((a) => a.id === addonId);
      return sum + (addon?.price || 0);
    }, 0);
    return model.price + addonsTotal;
  };

  const addonsByCategory = addons.reduce((acc, addon) => {
    if (!acc[addon.category]) {
      acc[addon.category] = [];
    }
    acc[addon.category].push(addon);
    return acc;
  }, {} as Record<string, typeof addons>);

  const handleProceedToCheckout = () => {
    // Store configuration in sessionStorage
    sessionStorage.setItem(
      "liftConfiguration",
      JSON.stringify({
        model,
        subcategory,
        category,
        selectedAddons: Array.from(selectedAddons).map((id) =>
          addons.find((a) => a.id === id)
        ),
        total: calculateTotal(),
      })
    );
    navigate("/checkout");
  };

  const handleDownloadSpec = () => {
    alert("Spec sheet download would start here. In production, this would download a PDF.");
  };

  return (
    <div className="w-full pb-20">
      {/* Breadcrumb */}
      <div className="bg-secondary/30 py-4 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Link to="/categories" className="hover:text-foreground">
              Categories
            </Link>
            <ChevronRight className="w-4 h-4" />
            <Link
              to={`/category/${category.id}`}
              className="hover:text-foreground"
            >
              {category.name}
            </Link>
            <ChevronRight className="w-4 h-4" />
            <span className="text-foreground">{model.name}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Back Button */}
            <Link
              to={`/category/${category.id}`}
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to {category.name}
            </Link>

            {/* Gallery */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="relative h-96 bg-muted">
                  <img
                    src={model.gallery[selectedImage]}
                    alt={model.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1 rounded text-sm font-mono">
                    {model.code}
                  </div>
                  <div className="absolute top-4 right-4 bg-background/90 backdrop-blur px-3 py-1 rounded text-sm">
                    {subcategory.name}
                  </div>
                </div>
                <div className="p-4 grid grid-cols-4 gap-2">
                  {model.gallery.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(idx)}
                      className={`relative h-20 rounded overflow-hidden border-2 transition-all ${
                        selectedImage === idx
                          ? "border-primary"
                          : "border-transparent hover:border-border"
                      }`}
                    >
                      <img
                        src={img}
                        alt={`View ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Product Info */}
            <div>
              <div className="mb-4">
                <span className="text-xs uppercase tracking-[0.3em] text-muted-foreground px-3 py-1 border border-border rounded-full">
                  {subcategory.code}
                </span>
              </div>
              <h1 className="text-4xl mb-4">{model.name}</h1>
              <p className="text-lg text-muted-foreground mb-6">
                {model.description}
              </p>

              {/* Quick Specs */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="p-4 bg-secondary/30 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                    Load Capacity
                  </div>
                  <div className="text-xl font-mono">{model.capacity} kg</div>
                </div>
                <div className="p-4 bg-secondary/30 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                    Passengers
                  </div>
                  <div className="text-xl font-mono">{model.passengers}</div>
                </div>
                <div className="p-4 bg-secondary/30 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                    Speed
                  </div>
                  <div className="text-xl font-mono">{model.speed}</div>
                </div>
                <div className="p-4 bg-secondary/30 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                    Base Price
                  </div>
                  <div className="text-xl font-mono">${model.price.toLocaleString()}</div>
                </div>
              </div>

              <button
                onClick={handleDownloadSpec}
                className="flex items-center gap-2 px-6 py-3 border border-border rounded-lg hover:bg-secondary transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download Spec Sheet</span>
              </button>
            </div>

            {/* Detailed Specifications */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-2xl mb-6 flex items-center gap-2">
                <Package className="w-6 h-6" />
                Technical Specifications
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(model.specifications).map(([key, value]) => (
                  <div key={key} className="pb-4 border-b border-border">
                    <div className="text-sm text-muted-foreground uppercase tracking-wide mb-2">
                      {key.replace(/([A-Z])/g, " $1").trim()}
                    </div>
                    {Array.isArray(value) ? (
                      <ul className="space-y-1">
                        {value.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div className="font-mono">{value}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Add-ons Section */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-2xl mb-2 flex items-center gap-2">
                <Zap className="w-6 h-6" />
                Optional Add-ons
              </h2>
              <p className="text-muted-foreground mb-6">
                Customize your lift with premium features and services
              </p>

              <div className="space-y-6">
                {Object.entries(addonsByCategory).map(([category, categoryAddons]) => (
                  <div key={category}>
                    <h3 className="text-sm uppercase tracking-wide text-muted-foreground mb-3">
                      {category}
                    </h3>
                    <div className="space-y-3">
                      {categoryAddons.map((addon) => (
                        <label
                          key={addon.id}
                          className="flex items-start gap-4 p-4 border border-border rounded-lg cursor-pointer hover:bg-secondary/30 transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={selectedAddons.has(addon.id)}
                            onChange={() => toggleAddon(addon.id)}
                            className="mt-1 w-5 h-5 flex-shrink-0"
                          />
                          <div className="flex-1">
                            <div className="flex items-start justify-between gap-4">
                              <div>
                                <div className="font-medium mb-1">{addon.name}</div>
                                <div className="text-sm text-muted-foreground">
                                  {addon.description}
                                </div>
                              </div>
                              <div className="text-right flex-shrink-0">
                                <div className="font-mono">+${addon.price.toLocaleString()}</div>
                              </div>
                            </div>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Price Summary Sidebar - Sticky */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="bg-card border border-border rounded-lg p-6">
                <h2 className="text-xl mb-6 flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Price Summary
                </h2>

                <div className="space-y-4 mb-6">
                  {/* Base Price */}
                  <div className="flex justify-between pb-4 border-b border-border">
                    <div>
                      <div className="font-medium">{model.name}</div>
                      <div className="text-sm text-muted-foreground">Base unit</div>
                    </div>
                    <div className="font-mono">${model.price.toLocaleString()}</div>
                  </div>

                  {/* Selected Add-ons */}
                  {Array.from(selectedAddons).length > 0 && (
                    <div className="space-y-3">
                      <div className="text-sm uppercase tracking-wide text-muted-foreground">
                        Add-ons
                      </div>
                      {Array.from(selectedAddons).map((addonId) => {
                        const addon = addons.find((a) => a.id === addonId);
                        if (!addon) return null;
                        return (
                          <div
                            key={addonId}
                            className="flex justify-between text-sm"
                          >
                            <span className="text-muted-foreground">{addon.name}</span>
                            <span className="font-mono">
                              +${addon.price.toLocaleString()}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Total */}
                  <div className="flex justify-between pt-4 border-t-2 border-primary">
                    <div>
                      <div className="text-sm text-muted-foreground uppercase tracking-wide">
                        Total Price
                      </div>
                    </div>
                    <div className="text-2xl font-mono">${calculateTotal().toLocaleString()}</div>
                  </div>
                </div>

                {/* CTA Buttons */}
                <div className="space-y-3">
                  <button
                    onClick={handleProceedToCheckout}
                    className="w-full px-6 py-4 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
                  >
                    Proceed to Checkout
                  </button>
                  <button className="w-full px-6 py-3 border border-border rounded-lg hover:bg-secondary transition-colors">
                    Request Quote
                  </button>
                </div>

                {/* Info */}
                <div className="mt-6 pt-6 border-t border-border space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5 text-primary" />
                    <span>Professional installation included</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5 text-primary" />
                    <span>5-year manufacturer warranty</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5 text-primary" />
                    <span>24/7 technical support</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}