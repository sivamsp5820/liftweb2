// Mock data for lift products

export interface LiftCategory {
  id: string;
  name: string;
  description: string;
  image: string;
  subcategories: string[];
}

export interface LiftSubcategory {
  id: string;
  categoryId: string;
  name: string;
  code: string;
  description: string;
  image: string;
  features: string[];
}

export interface LiftModel {
  id: string;
  subcategoryId: string;
  name: string;
  code: string;
  description: string;
  image: string;
  capacity: number; // kg
  passengers: number;
  speed: string;
  buildingType: string[];
  usage: string[];
  price: number;
  specifications: {
    loadCapacity: string;
    passengerCapacity: number;
    carDimensions: string;
    shaftDimensions: string;
    speed: string;
    powerRequirement: string;
    safetyFeatures: string[];
    installationType: string;
    travelHeight: string;
    doors: string;
  };
  gallery: string[];
}

export interface Addon {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
}

export const liftCategories: LiftCategory[] = [
  {
    id: 'doors',
    name: 'Doors',
    description: 'Premium door systems and components for elevator installations',
    image: 'https://images.unsplash.com/photo-1702483907449-7516bd7608a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGV2YXRvciUyMGNvbnRyb2wlMjBwYW5lbHxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    subcategories: ['CORE', 'CORE MD', 'STELLAR']
  },
  {
    id: 'non-doors',
    name: 'Non Doors',
    description: 'Essential lift components including cabins, mechanisms, and control systems',
    image: 'https://images.unsplash.com/photo-1765048808260-9f48d96caf98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbGlmdCUyMG1hbnVmYWN0dXJpbmd8ZW58MXx8fHwxNzcxOTE0MTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    subcategories: ['CABIN', 'SLING', 'MECHANISM', 'SYSTEM WITH', 'OL20']
  }
];

export const liftSubcategories: LiftSubcategory[] = [
  // Doors Category
  {
    id: 'core',
    categoryId: 'doors',
    name: 'CORE',
    code: 'CORE',
    description: 'Standard door system with robust construction and reliable operation for residential and light commercial applications',
    image: 'https://images.unsplash.com/photo-1702483907449-7516bd7608a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGV2YXRvciUyMGNvbnRyb2wlMjBwYW5lbHxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Automatic sliding mechanism', 'Stainless steel finish', 'Safety sensors', 'Quiet operation']
  },
  {
    id: 'core-md',
    categoryId: 'doors',
    name: 'CORE MD',
    code: 'CORE-MD',
    description: 'Medical-duty door system designed for healthcare facilities with antibacterial surfaces and wide openings',
    image: 'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Wide clear opening', 'Antibacterial coating', 'Stretcher compatible', 'Emergency override']
  },
  {
    id: 'stellar',
    categoryId: 'doors',
    name: 'STELLAR',
    code: 'STELLAR',
    description: 'Premium door system featuring advanced aesthetics and high-speed operation for luxury installations',
    image: 'https://images.unsplash.com/photo-1565897188739-4c8130c58a85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza3lzY3JhcGVyJTIwZ2xhc3MlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Premium glass panels', 'High-speed mechanism', 'LED lighting integration', 'Luxury finishes']
  },
  // Non Doors Category
  {
    id: 'cabin',
    categoryId: 'non-doors',
    name: 'CABIN',
    code: 'CABIN',
    description: 'Complete cabin solutions with customizable interior finishes and lighting options',
    image: 'https://images.unsplash.com/photo-1770821030454-5e3ccb2d96dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXNpZGVudGlhbCUyMGhvbWUlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Modular design', 'Multiple finish options', 'LED ceiling panels', 'Mirror walls available']
  },
  {
    id: 'sling',
    categoryId: 'non-doors',
    name: 'SLING',
    code: 'SLING',
    description: 'Structural sling frames providing the foundation for lift cabin installation',
    image: 'https://images.unsplash.com/photo-1765048808260-9f48d96caf98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbGlmdCUyMG1hbnVmYWN0dXJpbmd8ZW58MXx8fHwxNzcxOTE0MTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Heavy-duty steel construction', 'Precision engineering', 'Anti-vibration mounts', 'Quick installation']
  },
  {
    id: 'mechanism',
    categoryId: 'non-doors',
    name: 'MECHANISM',
    code: 'MECH',
    description: 'Advanced drive mechanisms and motor systems for smooth and efficient lift operation',
    image: 'https://images.unsplash.com/photo-1769734711473-6544be810904?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVpZ2h0JTIwY2FyZ28lMjBsaWZ0fGVufDF8fHx8MTc3MTkxNDE0OHww&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Energy-efficient motors', 'Regenerative drive', 'Low maintenance', 'Precision control']
  },
  {
    id: 'system-with',
    categoryId: 'non-doors',
    name: 'SYSTEM WITH',
    code: 'SYS-W',
    description: 'Complete integrated lift systems with all components included for turnkey installation',
    image: 'https://images.unsplash.com/photo-1544415224-e4b67cd64504?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tZXJjaWFsJTIwYnVpbGRpbmclMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['All-inclusive package', 'Pre-configured system', 'Faster installation', 'Complete warranty']
  },
  {
    id: 'ol20',
    categoryId: 'non-doors',
    name: 'OL20',
    code: 'OL20',
    description: 'Compact overload-rated system designed for space-constrained installations',
    image: 'https://images.unsplash.com/photo-1695067440629-b5e513976100?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzE4OTU5ODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Space-saving design', 'Overload protection', 'Machine room less', 'Modern aesthetics']
  }
];

export const liftModels: LiftModel[] = [
  // CORE Models
  {
    id: 'core-100',
    subcategoryId: 'core',
    name: 'CORE 100 Standard',
    code: 'CORE-100',
    description: 'Entry-level door system perfect for residential and small commercial buildings',
    image: 'https://images.unsplash.com/photo-1702483907449-7516bd7608a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGV2YXRvciUyMGNvbnRyb2wlMjBwYW5lbHxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 450,
    passengers: 6,
    speed: '1.0 m/s',
    buildingType: ['Residential', 'Small Commercial'],
    usage: ['Low Traffic', 'Medium Traffic'],
    price: 8500,
    specifications: {
      loadCapacity: '450 kg',
      passengerCapacity: 6,
      carDimensions: '900 x 2100 mm opening',
      shaftDimensions: '1200 x 1400 mm',
      speed: '0.4 m/s opening speed',
      powerRequirement: '0.75 kW, 220V',
      safetyFeatures: ['Infrared sensors', 'Emergency stop', 'Door interlock', 'Anti-pinch protection'],
      installationType: 'Standard mounting',
      travelHeight: 'Suitable for all heights',
      doors: 'Automatic center-opening, stainless steel'
    },
    gallery: [
      'https://images.unsplash.com/photo-1702483907449-7516bd7608a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGV2YXRvciUyMGNvbnRyb2wlMjBwYW5lbHxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  {
    id: 'core-200',
    subcategoryId: 'core',
    name: 'CORE 200 Premium',
    code: 'CORE-200',
    description: 'Enhanced door system with faster operation and premium finishes',
    image: 'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 630,
    passengers: 8,
    speed: '1.6 m/s',
    buildingType: ['Commercial', 'Office', 'Residential'],
    usage: ['Medium Traffic', 'High Traffic'],
    price: 12800,
    specifications: {
      loadCapacity: '630 kg',
      passengerCapacity: 8,
      carDimensions: '1100 x 2100 mm opening',
      shaftDimensions: '1500 x 1700 mm',
      speed: '0.6 m/s opening speed',
      powerRequirement: '1.1 kW, 380V',
      safetyFeatures: ['Advanced infrared sensors', 'Emergency stop', 'Door interlock', 'Anti-pinch protection', 'Soft start/stop'],
      installationType: 'Standard/MRL compatible',
      travelHeight: 'Suitable for all heights',
      doors: 'Automatic center-opening, brushed stainless steel'
    },
    gallery: [
      'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1702483907449-7516bd7608a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGV2YXRvciUyMGNvbnRyb2wlMjBwYW5lbHxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // CORE MD Models
  {
    id: 'core-md-100',
    subcategoryId: 'core-md',
    name: 'CORE MD Hospital',
    code: 'CORE-MD-100',
    description: 'Medical-grade door system with wide opening for stretcher access',
    image: 'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 1600,
    passengers: 21,
    speed: '1.6 m/s',
    buildingType: ['Hospital', 'Medical Center', 'Clinic'],
    usage: ['High Traffic', 'Medical'],
    price: 18500,
    specifications: {
      loadCapacity: '1600 kg',
      passengerCapacity: 21,
      carDimensions: '1400 x 2400 mm opening',
      shaftDimensions: '1800 x 2800 mm',
      speed: '0.5 m/s opening speed',
      powerRequirement: '1.5 kW, 380V',
      safetyFeatures: ['Medical-grade sensors', 'Emergency override', 'Antibacterial coating', 'Backup power compatible', 'Soft operation'],
      installationType: 'Medical facility approved',
      travelHeight: 'Suitable for all heights',
      doors: 'Wide automatic center-opening, antibacterial stainless steel'
    },
    gallery: [
      'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1702483907449-7516bd7608a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGV2YXRvciUyMGNvbnRyb2wlMjBwYW5lbHxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // STELLAR Models
  {
    id: 'stellar-300',
    subcategoryId: 'stellar',
    name: 'STELLAR 300 Luxury',
    code: 'STELLAR-300',
    description: 'Premium glass door system for high-end residential and commercial installations',
    image: 'https://images.unsplash.com/photo-1565897188739-4c8130c58a85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza3lzY3JhcGVyJTIwZ2xhc3MlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 800,
    passengers: 10,
    speed: '2.5 m/s',
    buildingType: ['Luxury Residential', 'Hotel', 'Premium Commercial'],
    usage: ['Medium Traffic', 'High Traffic'],
    price: 24500,
    specifications: {
      loadCapacity: '800 kg',
      passengerCapacity: 10,
      carDimensions: '1200 x 2300 mm opening',
      shaftDimensions: '1600 x 2000 mm',
      speed: '0.8 m/s opening speed',
      powerRequirement: '2.2 kW, 380V',
      safetyFeatures: ['Premium sensors', 'Tempered glass panels', 'LED lighting', 'Whisper-quiet operation', 'Smart control'],
      installationType: 'Premium mounting system',
      travelHeight: 'Suitable for all heights',
      doors: 'Automatic center-opening, tempered glass with stainless steel frame'
    },
    gallery: [
      'https://images.unsplash.com/photo-1565897188739-4c8130c58a85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza3lzY3JhcGVyJTIwZ2xhc3MlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // CABIN Models
  {
    id: 'cabin-standard',
    subcategoryId: 'cabin',
    name: 'CABIN Standard Series',
    code: 'CABIN-STD',
    description: 'Versatile cabin solution with multiple finish options',
    image: 'https://images.unsplash.com/photo-1770821030454-5e3ccb2d96dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXNpZGVudGlhbCUyMGhvbWUlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 630,
    passengers: 8,
    speed: '1.0 m/s',
    buildingType: ['Residential', 'Commercial', 'Office'],
    usage: ['Low Traffic', 'Medium Traffic'],
    price: 15600,
    specifications: {
      loadCapacity: '630 kg',
      passengerCapacity: 8,
      carDimensions: '1400 x 1400 x 2200 mm',
      shaftDimensions: '1750 x 1750 mm',
      speed: '1.0 m/s',
      powerRequirement: '7.5 kW, 380V',
      safetyFeatures: ['LED lighting', 'Ventilation system', 'Emergency phone', 'Non-slip flooring'],
      installationType: 'Modular assembly',
      travelHeight: 'Up to 60m',
      doors: 'Compatible with all door systems'
    },
    gallery: [
      'https://images.unsplash.com/photo-1770821030454-5e3ccb2d96dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXNpZGVudGlhbCUyMGhvbWUlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // SLING Models
  {
    id: 'sling-hd',
    subcategoryId: 'sling',
    name: 'SLING Heavy Duty',
    code: 'SLING-HD',
    description: 'Robust sling frame for commercial and industrial applications',
    image: 'https://images.unsplash.com/photo-1765048808260-9f48d96caf98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbGlmdCUyMG1hbnVmYWN0dXJpbmd8ZW58MXx8fHwxNzcxOTE0MTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 1000,
    passengers: 13,
    speed: '1.6 m/s',
    buildingType: ['Commercial', 'Industrial', 'Office'],
    usage: ['Medium Traffic', 'High Traffic'],
    price: 9800,
    specifications: {
      loadCapacity: '1000 kg',
      passengerCapacity: 13,
      carDimensions: '1600 x 1600 x 2400 mm',
      shaftDimensions: '2000 x 2000 mm',
      speed: '1.6 m/s',
      powerRequirement: '11 kW, 380V',
      safetyFeatures: ['Reinforced steel frame', 'Anti-vibration mounts', 'Precision alignment', 'Corrosion resistant'],
      installationType: 'Structural mounting',
      travelHeight: 'Up to 100m',
      doors: 'Compatible with all door systems'
    },
    gallery: [
      'https://images.unsplash.com/photo-1765048808260-9f48d96caf98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbGlmdCUyMG1hbnVmYWN0dXJpbmd8ZW58MXx8fHwxNzcxOTE0MTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1769734711473-6544be810904?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVpZ2h0JTIwY2FyZ28lMjBsaWZ0fGVufDF8fHx8MTc3MTkxNDE0OHww&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // MECHANISM Models
  {
    id: 'mechanism-eco',
    subcategoryId: 'mechanism',
    name: 'MECHANISM EcoMotor',
    code: 'MECH-ECO',
    description: 'Energy-efficient drive system with regenerative technology',
    image: 'https://images.unsplash.com/photo-1769734711473-6544be810904?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVpZ2h0JTIwY2FyZ28lMjBsaWZ0fGVufDF8fHx8MTc3MTkxNDE0OHww&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 800,
    passengers: 10,
    speed: '2.0 m/s',
    buildingType: ['Commercial', 'Office', 'Residential'],
    usage: ['Medium Traffic', 'High Traffic'],
    price: 22400,
    specifications: {
      loadCapacity: '800 kg',
      passengerCapacity: 10,
      carDimensions: 'Compatible with standard cabins',
      shaftDimensions: 'Machine room less design',
      speed: '2.0 m/s',
      powerRequirement: '11 kW, 380V (40% energy saving)',
      safetyFeatures: ['Regenerative drive', 'Soft start/stop', 'Emergency lowering', 'Overspeed protection'],
      installationType: 'Machine Room Less (MRL)',
      travelHeight: 'Up to 80m',
      doors: 'Compatible with all systems'
    },
    gallery: [
      'https://images.unsplash.com/photo-1769734711473-6544be810904?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVpZ2h0JTIwY2FyZ28lMjBsaWZ0fGVufDF8fHx8MTc3MTkxNDE0OHww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1765048808260-9f48d96caf98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbGlmdCUyMG1hbnVmYWN0dXJpbmd8ZW58MXx8fHwxNzcxOTE0MTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // SYSTEM WITH Models
  {
    id: 'system-complete',
    subcategoryId: 'system-with',
    name: 'SYSTEM WITH Complete Package',
    code: 'SYS-W-FULL',
    description: 'All-inclusive lift system ready for installation',
    image: 'https://images.unsplash.com/photo-1544415224-e4b67cd64504?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tZXJjaWFsJTIwYnVpbGRpbmclMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 630,
    passengers: 8,
    speed: '1.6 m/s',
    buildingType: ['Commercial', 'Office', 'Residential', 'Hotel'],
    usage: ['Medium Traffic', 'High Traffic'],
    price: 52000,
    specifications: {
      loadCapacity: '630 kg',
      passengerCapacity: 8,
      carDimensions: '1400 x 1400 x 2200 mm',
      shaftDimensions: '1750 x 1750 mm',
      speed: '1.6 m/s',
      powerRequirement: '11 kW, 380V, 3-phase',
      safetyFeatures: ['Complete safety package', 'Emergency brake', 'ARD ready', 'All sensors included', 'Fire service mode'],
      installationType: 'Turnkey solution',
      travelHeight: 'Up to 60m (20 floors)',
      doors: 'CORE doors included'
    },
    gallery: [
      'https://images.unsplash.com/photo-1544415224-e4b67cd64504?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tZXJjaWFsJTIwYnVpbGRpbmclMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1621293954908-907159247fc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGV2YXRvciUyMGludGVyaW9yJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTkxNDE0N3ww&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  },
  // OL20 Models
  {
    id: 'ol20-compact',
    subcategoryId: 'ol20',
    name: 'OL20 Compact',
    code: 'OL20-C',
    description: 'Space-efficient overload system for modern buildings',
    image: 'https://images.unsplash.com/photo-1695067440629-b5e513976100?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzE4OTU5ODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    capacity: 400,
    passengers: 5,
    speed: '1.0 m/s',
    buildingType: ['Residential', 'Small Commercial', 'Boutique'],
    usage: ['Low Traffic', 'Medium Traffic'],
    price: 19200,
    specifications: {
      loadCapacity: '400 kg',
      passengerCapacity: 5,
      carDimensions: '1000 x 1200 x 2100 mm',
      shaftDimensions: '1300 x 1500 mm',
      speed: '1.0 m/s',
      powerRequirement: '5.5 kW, 380V',
      safetyFeatures: ['Overload sensor', 'Compact design', 'MRL technology', 'Smart monitoring'],
      installationType: 'Machine Room Less (MRL)',
      travelHeight: 'Up to 30m (10 floors)',
      doors: 'Compatible with CORE doors'
    },
    gallery: [
      'https://images.unsplash.com/photo-1695067440629-b5e513976100?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzE4OTU5ODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1770821030454-5e3ccb2d96dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXNpZGVudGlhbCUyMGhvbWUlMjBlbGV2YXRvcnxlbnwxfHx8fDE3NzE5MTQxNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080'
    ]
  }
];

export const addons: Addon[] = [
  {
    id: 'ard',
    name: 'Automatic Rescue Device (ARD)',
    description: 'Emergency power system that safely moves the lift to the nearest floor during power outages',
    price: 4500,
    category: 'Safety'
  },
  {
    id: 'premium-cabin',
    name: 'Premium Cabin Finish',
    description: 'Luxury cabin interior with marble flooring, LED lighting, and premium wall panels',
    price: 8200,
    category: 'Aesthetics'
  },
  {
    id: 'smart-control',
    name: 'Smart Control Panel',
    description: 'Touchscreen control panel with destination selection and IoT integration',
    price: 3600,
    category: 'Technology'
  },
  {
    id: 'extra-sensors',
    name: 'Extra Safety Sensors',
    description: 'Advanced sensor package including infrared door sensors and anti-collision system',
    price: 2100,
    category: 'Safety'
  },
  {
    id: 'maintenance-basic',
    name: 'Basic Maintenance Package',
    description: '12-month preventive maintenance with quarterly inspections',
    price: 1800,
    category: 'Service'
  },
  {
    id: 'maintenance-premium',
    name: 'Premium Maintenance Package',
    description: '24-month comprehensive maintenance with monthly inspections and priority service',
    price: 4200,
    category: 'Service'
  },
  {
    id: 'glass-cabin',
    name: 'Glass Cabin Walls',
    description: 'Panoramic glass walls for scenic elevator experience',
    price: 12500,
    category: 'Aesthetics'
  },
  {
    id: 'air-purifier',
    name: 'HEPA Air Purification System',
    description: 'Medical-grade air filtration system with UV sterilization',
    price: 2800,
    category: 'Health'
  }
];
